"""
URL configuration for homologacion project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView
)

urlpatterns = [
    # Descarga del esquema YAML/JSON
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),

    # UI de Swagger (La más común)
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),

    # UI de Redoc (Alternativa más limpia)
    path('api/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),

    path('admin/', admin.site.urls),
    path('api/auth/', include('dj_rest_auth.urls')),
    # Rutas para registro de nuevos usuarios
    path('api/auth/registration/', include('dj_rest_auth.registration.urls')),
    # Rutas del core (equipos homologados, etc.)
    path('api/', include('core.urls')),
    path('api/', include('user.urls')),
]

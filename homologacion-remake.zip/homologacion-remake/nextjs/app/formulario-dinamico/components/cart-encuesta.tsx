import {
  Button,
  Card,
  CardContent,
  Checkbox,
  Input,
  Label,
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
  Separator,
} from "@/components/ui";
import { Plus, X } from "lucide-react";
import { JSX, useState } from "react";
import useSWR from "swr";
import { getCategorias } from "../api/api-categorias";
import { getTipoPreguntas } from "../api/api-tipo-encuesta";
export function CartEncuesta() {
  const [event, setEvent] = useState<string>("");
  const [title, setTitle] = useState<string>("");
  const [textField, setTextField] = useState<{ title: string }[]>([]);
  const [uniqueOption, setUniqueOption] = useState<
    { id: number; title: string }[]
  >([]);
  const [titleUniqueOption, setTitleUniqueOption] = useState<string>("");

  const { data: categorias } = useSWR(
    "api/categorias",
    async () => await getCategorias(),
  );

  const { data: tipoPregunta } = useSWR(
    "api/tipo-pregunta",
    async () => await getTipoPreguntas(),
  );
  interface TextField {
    title: string;
  }
  const textFieldFn = () => {
    setTextField((prev) => [...prev, { title: title }]);
  };
  const deleteTextField = (index: number) => {
    setTextField((prev) => prev.filter((_, i) => i !== index));
  };

  const uniqueOptionFn = () => {
    setUniqueOption((prev) => [
      ...prev,
      { id: prev.length + 1, title: titleUniqueOption },
    ]);
    console.log(uniqueOption);
  };

  const selectEventConstructForm = () => {
    if (event === "texto_libre") {
      textFieldFn();
    }
    if (event === "opcion_unica") {
      uniqueOptionFn();
    }
    if (event === "opcion_multiple") {
    }
    if (event === "escala_numerica") {
    }
    if (event === "fecha") {
    }
  };
  return (
    <div className="relative w-full">
      <Card className="grow ">
        <div className="absolute right-0 top-0 self-end -translate-y-2.5 translate-x-2.5 flex flex-row gap">
          <Button type="button" onClick={() => selectEventConstructForm()}>
            Agregar <Plus />
          </Button>
        </div>
        <CardContent className="mt-2">
          <div className="flex flex-row gap-2 ">
            <Input
              className="grow"
              placeholder="Pregunta Sin Titulo"
              onChange={(e) => setTitle(e.target.value)}
            />
            <Select onValueChange={(e) => setEvent(e)}>
              <SelectTrigger className="w-full max-w-48 grow">
                <SelectValue placeholder="Selecciona un tipo de encuesta" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Tipo de Preguntas</SelectLabel>
                  {tipoPregunta?.map((v, i) => (
                    <SelectItem key={i} value={v.tipo_pregunta}>
                      {v.tipo_pregunta}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          {event !== "texto_libre" && <Separator className="mt-2" />}
          {event == "opcion_unica" && (
            <div className="relative w-full mt-4 flex flex-col">
              <Button
                className="absolute top-0 right-0 -translate-y-2 text-sm "
                type="button"
                onClick={() => uniqueOptionFn()}
              >
                Agregar Opcion
                <Plus />
              </Button>
              {uniqueOption.map((v, i) => (
                <div className="flex flex-row gap-2 mt-6" key={i}>
                  <Checkbox className="self-center" disabled />{" "}
                  <Input
                    placeholder="Titulo..."
                    className="border-l-0 border-r-0 border-t-0 rounded-none transition-all hover:border-b-2 ring-offset-0 focus:outline-none  focus-visible:ring-0 "
                    onChange={(e) => setTitleUniqueOption(e.target.value)}
                  />
                </div>
              ))}
            </div>
          )}
        </CardContent>
        {textField.map((v, i) => (
          <div key={i} className="flex flex-row gap-2 justify-around">
            <div>
              <Label>{v.title}</Label>
              <Input />
            </div>
            <Button
              type="button"
              variant={"destructive"}
              className="self-baseline-last"
              disabled={textField[i].title.length > 1}
              onClick={() => deleteTextField(i)}
            >
              <X />
            </Button>
          </div>
        ))}
      </Card>
    </div>
  );
}
